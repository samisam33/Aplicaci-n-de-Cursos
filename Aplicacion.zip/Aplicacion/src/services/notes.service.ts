import { Injectable } from '@angular/core';//Sirve para llamar este elemento en cualquier lado del proyecto
//Servicio para los talleres 
import { AngularFireDatabase } from '@angular/fire/database';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class NotesService{

	constructor(public afDB: AngularFireDatabase){
		//this.notes = afDB.list('cuisines').valueChanges();
	}

	notes = [];
	public getTalleres() {
		//return this.notes;
		return this.afDB.list('notas/').valueChanges();
	}

	public getTaller(id) {
		//return this.notes.filter(function(e, i){return e.id == id})[0] || {id: null, title: null, descripcion: null};
		return this.afDB.object('notas/'+id);
	}

	public crearTaller(taller) {
		this.afDB.database.ref('notas/'+taller.id).set(taller);
		//this.notes.push(note);
	}

	public editarTaller(taller) {
		/*for (let i = 0; i < this.notes.length; i++) {
			if (this.notes[i].id == note.id) {
				this.notes[i] = note;
			}
		}*/
		this.afDB.database.ref('notas/'+taller.id).set(taller);
	}

	public eliminarTaller(taller) {
		/*for (let i = 0; i < this.notes.length; i++) {
			if (this.notes[i].id == note.id) {
				this.notes.splice(i, 1);
			}
		}*/
		this.afDB.database.ref('notas/'+taller.id).remove();	
	}
	//
	public registrarme(taller2) {
		this.afDB.database.ref('notas/1543768906407/'+taller2.id).set(taller2);
		//this.notes.push(note);
	}
}