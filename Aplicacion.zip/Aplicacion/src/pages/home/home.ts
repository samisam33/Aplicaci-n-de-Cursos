import { Component,ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { NotesService } from '../../services/notes.service';
import { DetailPage } from '../detail/detail';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

	talleres=[];	
  	@ViewChild('myNav') nav: NavController;

  constructor(public navCtrl: NavController, public notesService: NotesService) {
  	this.notesService.getTalleres().subscribe( tallerf => {
  		this.talleres = tallerf;
  	});//importamos las notas desde notes.service
  }

  public irATalleres(id) {
  	this.navCtrl.push(DetailPage, {id:id});
  }

  public crearTaller() {
  	this.navCtrl.push(DetailPage, {id:0});//Cero para que se indique que es una nueva nota
  }

}
