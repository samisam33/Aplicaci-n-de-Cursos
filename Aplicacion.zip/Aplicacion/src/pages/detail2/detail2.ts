import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { NotesService } from '../../services/notes.service';

/**
 * Generated class for the Detail2Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-detail2',
  templateUrl: 'detail2.html',
})
export class Detail2Page {

	taller2:any = {id: null, nombre: null, aP: null, aM: null, email: null, cO: null, 
					cuenta: null, telefono: null};
	id: null;

  constructor(public navCtrl: NavController, public navParams: NavParams, public notesService: NotesService) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Detail2Page');
  }

  public reg() {
  	this.taller2.id = Date.now();//Genera un ID
 	this.notesService.registrarme(this.taller2);
  	alert("Registro Exitoso!");
  	this.navCtrl.pop();
  }
}
