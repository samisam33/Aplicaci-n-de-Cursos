import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { NotesService } from '../../services/notes.service';
import { Detail2Page } from '../detail2/detail2';

/**
 * Generated class for the DetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-detail',
  templateUrl: 'detail.html',
})
export class DetailPage {

	taller:any = {id: null, title: null, nInstructor: null, description: null, temario: null,
					duracion: null, fic: null, ftc: null, hc1: null, hc2: null, fii: null,
					fti: null, lugar: null, maximo: null, minimo: null, costo: null, observaciones: null};
	id = null;

  constructor(public navCtrl: NavController, public navParams: NavParams, public notesService: NotesService) {
  	this.id = navParams.get('id');//Obtiene el id de la nota que se seleccione
  	if(this.id != 0) {
  		notesService.getTaller(this.id)
  		.valueChanges().subscribe( taller => {
  			console.log(taller)
  			this.taller = taller;
  		});
  	}
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DetailPage');
  }

  agregarTaller() {
  	if(this.id != 0) {
  		//editando
  		this.notesService.editarTaller(this.taller);
  		alert("Taller editad con exito!");
  	} else {
  		this.taller.id = Date.now();//Genera un ID
  		this.notesService.crearTaller(this.taller);
  		alert("Taller creado con exito!");
  	}
  	this.navCtrl.pop();
  }

  eliminarTaller() {
  	this.notesService.eliminarTaller(this.taller);
  	alert("Taller eliminado con exito!");
  	this.navCtrl.pop();
  }
/////
  registrar() {
    this.navCtrl.push(Detail2Page, {id:0});
    //this.taller.id = Date.now();//Genera un ID
    //this.notesService.crearTaller(this.taller);
    //alert("Registro Satisfactorio!");
  }

}
