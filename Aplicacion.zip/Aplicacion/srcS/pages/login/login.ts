import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';


/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

	usuario: string = "Jaziel";
	contra: string = "Game";
	user: string;
	pass: string;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  IniciarSesion(){
  		if (this.user == this.usuario && this.pass == this.contra) {
  			this.navCtrl.push(HomePage);
  			console.log("Ingresado bien");
  		} else {
  			console.log("Acceso denegado");
  		}
  	}

}
