import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../home/home';
import { NotesService } from '../../services/notes.service';
import { Detail3Page } from '../detail3/detail3';

/**
 * Generated class for the Detail2Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-detail2',
  templateUrl: 'detail2.html',
})
export class Detail2Page {

	talleres2 = [];

  constructor(public navCtrl: NavController, public navParams: NavParams, public notesService: NotesService) {
  	this.notesService.getTalleres2().subscribe( tallerf2 => {
  		this.talleres2 = tallerf2;
  	});
  }

  public irARegistros(id) {
  	this.navCtrl.push(Detail3Page, {id:id});
  }

  principal() {
    this.navCtrl.push(HomePage);
  }

  public crearRegistro() {
  	this.navCtrl.push(Detail3Page, {id:0});//Cero para que se indique que es una nueva nota
  }

}
