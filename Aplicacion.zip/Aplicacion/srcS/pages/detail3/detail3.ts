import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { NotesService } from '../../services/notes.service';

/**
 * Generated class for the Detail3Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-detail3',
  templateUrl: 'detail3.html',
})
export class Detail3Page {

	taller2:any = {id: null, nombre: null, aP: null, aM: null, email: null,
					cO: null, cuenta: null, telefono: null};
	id = null;

  constructor(public navCtrl: NavController, public navParams: NavParams, public notesService: NotesService) {
  	this.id = navParams.get('id');//Obtiene el id de la nota que se seleccione
  	if(this.id != 0) {
  		notesService.getTaller2(this.id)
  		.valueChanges().subscribe( taller2 => {
  			console.log(taller2)
  			this.taller2 = taller2;
  		});
  	}
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Detail3Page');
  }

  agregarRegistro() {
  	if(this.id != 0) {
  		//editando
  		this.notesService.editarTaller2(this.taller2);
  		alert("Taller editad con exito!");
  	} else {
  		this.taller2.id = Date.now();//Genera un ID
  		this.notesService.crearTaller2(this.taller2);
  		alert("Taller creado con exito!");
  	}
  	this.navCtrl.pop();
  }

  eliminarRegistro() {
  	this.notesService.eliminarTaller2(this.taller2);
  	alert("Taller eliminado con exito!");
  	this.navCtrl.pop();
  }

}
