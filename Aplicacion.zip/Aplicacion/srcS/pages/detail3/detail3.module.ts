import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Detail3Page } from './detail3';

@NgModule({
  declarations: [
    Detail3Page,
  ],
  imports: [
    IonicPageModule.forChild(Detail3Page),
  ],
})
export class Detail3PageModule {}
